# Quick Filter

An addon for Firefox OS that allows you to toggle the accessibility color filter setting by triple tapping on the camera focus button.
